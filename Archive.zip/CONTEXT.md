# Music Roulette — Project Context

## Meta
- **Repo:** https://github.com/robixeddu/music-roulette
- **Deploy:** https://music-roulette-seven.vercel.app/
- **Stack:** Next.js 15, React 19, TypeScript, CSS Modules + `globals.css` per token, iTunes Search API, Neon Postgres
- **Turbopack** in dev, Vercel deploy
- **Test:** Jest + Testing Library, Playwright e2e
- **DB driver:** `@neondatabase/serverless` — `lib/db.ts` esporta `sql`

---

## Font

Caricati in `layout.tsx` via `next/font/google`, iniettati come CSS vars sull'`<html>`:

| Var | Font | Uso |
|-----|------|-----|
| `--font-display` | **Syne** (400/700/800) | Titoli, nomi genere, h1/h2 |
| `--font-mono` | **Space Mono** (400/700) | UI, etichette, punteggi, bottoni |

- `globals.css` NON ha `@import` font
- Non tornare a Bebas Neue, Michroma, Oxanium — scelto Syne dopo confronto

---

## Internazionalizzazione (i18n)

- **File:** `lib/i18n.ts` — dizionario `TRANSLATIONS` con 5 lingue
- **Hook:** `hooks/useLocale.ts` — rileva `navigator.language` dopo il mount (evita hydration mismatch)
- **Lingue supportate:** `it` (default) · `en` · `es` · `fr` · `de`
- **Rilevamento:** `useState(DEFAULT_LOCALE)` + `useEffect(() => setLocale(detect()))` — SSR sempre italiano, poi aggiornamento client-side silenzioso
- **Generi e livelli:** non tradotti (nomi invariati)
- Tutti i componenti client usano `const { t } = useLocale()`

---

## Architettura

```
app/
  layout.tsx              RSC. Font Syne + Space Mono via next/font/google.
                          Viewport anti-zoom iOS.
  globals.css             Token CSS (:root vars), reset. NO @import font.
  page.tsx                'use client'. Homepage: hero + regole i18n + ArtistSearch
  home.module.css
  game/
    page.tsx              RSC async. firstQuestionPromise server-side.
                          Usa <GameNav> (client) per backLabel tradotto.
  genres/
    page.tsx              'use client'. Lista generi raggruppati via GenreGrid.
  leaderboard/
    page.tsx              'use client'. Polling 12s, top 50, tab Globale/Generi/Artisti.
  api/
    artists/route.ts      GET ?q= → iTunes, cache 5min
    track/route.ts        GET ?genreId= | ?artistName= & ?usedIds= → no-store
    leaderboard/route.ts  GET top50 | GET ?check=N | POST score → Neon

components/
  AppNav.tsx              RSC. Prop showDot?: boolean — pallino accent prima del titolo.
  ArtistSearch.tsx        'use client'. Autocomplete bottom sheet / smart flip.
  AudioPlayer.tsx         'use client'. autoplay, onFirstPlay, playBtnRef, fadeout RAF.
  Btn.module.css
  ChoiceList.tsx          4 opzioni. Colori corretto/sbagliato. No icone ✓/✗.
  ErrorBoundary.tsx
  GameController.tsx      'use client'. Prefetch, suoni Web Audio, feedbackDelayMs, wonLevelRef.
  GameError.tsx
  GameNav.tsx             'use client'. Wrapper AppNav con backLabel tradotto via useLocale.
  GameOver.tsx            'use client'. Modal score con AbortController. Bottone ✕ 2.5rem.
                          ENTER YOUR NAME centrato sopra l'input (non sull'intera row).
  GameSkeleton.tsx
  GenreGrid.tsx           'use client'. Card raggruppate per genre.group. Banda colorata 48px.
  LivesIndicator.tsx
  Prize.tsx               onAdvanceLevel() al mount. UI rimane finché utente non clicca.
  QuestionView.tsx        'use client'. autoplay=true, focus rAF, cover svelata su risposta.
  RetryButtons.tsx
  ThemeProvider.tsx

lib/
  types.ts      Genre: id, name, emoji (non usata), group, searchTerms[]
  levels.ts     LEVELS[], getTimeMultiplier, calcLeaderboardScore, loadLevel/saveLevel
  itunes.ts     pickQuestionTracks: fake con artisti diversi dalla correct e tra loro
  genres.ts     25 generi con group, searchTerms (20 artisti), GENRE_THEMES neon arcade
  game-utils.ts applyGuess, getPrize, formatScore, makeInitialState
  i18n.ts       Dizionario traduzioni 5 lingue (it/en/es/fr/de)
  db.ts         neon(POSTGRES_URL) → export sql
  utils.ts      shuffleArray

hooks/
  useLocale.ts  Rileva lingua browser post-mount, espone t(key, vars?)
```

---

## Generi (25, raggruppati)

| Group | Generi |
|-------|--------|
| Pop | Pop, Brit Pop, K-Pop |
| Rock | Rock, Hard Rock, Stoner Rock, Post Rock |
| Metal | Metal, Thrash Metal, Death Metal, Black Metal |
| Hip-Hop | Rap, Hip-Hop |
| Electronic | Electronic |
| Jazz | Jazz |
| Soul | R&B, Funk & Soul |
| Blues | Blues |
| Folk | Folk, Country |
| Punk | Punk, Hardcore |
| Reggae | Reggae, Dub |
| Classical | Classical |

Ogni genere: `id`, `name`, `group`, `searchTerms[]` (20 artisti), tema in `GENRE_THEMES`.

---

## Palette colori — neon arcade anni 80

Banda GenreGrid: `color-mix(accent 55%, transparent)` a riposo → 72% su hover.

| Genere | Accent |
|--------|--------|
| Pop | #ff2d78 |
| Brit Pop | #ffe600 |
| K-Pop | #ff00cc |
| Rock | #ff3300 |
| Hard Rock | #ff7700 |
| Stoner Rock | #ccff00 |
| Post Rock | #00cfff |
| Metal | #e8e8ff |
| Thrash Metal | #ff0022 |
| Death Metal | #cc0000 |
| Black Metal | #7755ff |
| Rap | #ffd000 |
| Hip-Hop | #ff6600 |
| Electronic | #00ffe0 |
| Jazz | #ffaa00 |
| R&B | #cc44ff |
| Funk & Soul | #ff8800 |
| Blues | #2266ff |
| Folk | #dd9933 |
| Country | #ffcc44 |
| Punk | #ff0088 |
| Hardcore | #ff2200 |
| Reggae | #00ee44 |
| Dub | #00ccff |
| Classical | #fff0cc |

---

## GenreGrid — card design

- Banda colorata 48px in cima, nessun pattern SVG, nessuna emoji
- Nome: Syne, `min-height: 2.8rem`, testo con wrap naturale
- `border-radius: 3px`
- Mobile: 2 colonne fisse; desktop ≥480px: `auto-fill minmax(110px)`

---

## Leaderboard — tab

- **Globale** — tutti gli entry
- **Generi** — entry dove `genre` è in `GENRE_KEYS` (id o name dei generi)
- **Artisti** — entry dove `genre` non è in `GENRE_KEYS` (= nome artista)
- Filtro client-side su dati già caricati, nessuna modifica al DB

---

## Livelli

| id | name   | winScore | multiplier | feedbackDelayMs |
|----|--------|----------|------------|-----------------|
| 1  | Rookie | 5        | ×1         | 1500ms          |
| 2  | Arcade | 8        | ×2         | 1200ms          |
| 3  | Expert | 12       | ×3         | 1000ms          |
| 4  | Master | 15       | ×5         | 800ms           |

---

## Flusso di gioco

```
Giochi → Vinci livello 1-3 → Prize:
           onAdvanceLevel() al mount (background)
           UI rimane con box "Prossimo livello: X"
           RetryButtons per continuare o cambiare artista
       → Avanza livello → partita successiva usa già il nuovo livello
       → Vinci Master  → GameOver isVictory=true + bottone "Salva punteggio" esplicito
       → Perdi vite    → GameOver isVictory=false + modal auto (AbortController)
```

**wonLevelRef** congela il livello al momento della vittoria.
**Modal score** non si apre mai automaticamente su `isVictory=true`.

---

## Punteggio classifica

```
leaderboardScore = round(domande_vinte × moltiplicatore_livello × moltiplicatore_tempo)
moltiplicatore_tempo = max(0.5, 3.0 − (s / 30) × 2.5)
```

---

## Salvataggio score — top 50

1. Mount `GameOver` (`lost`): fetch con `AbortController`
2. `eligible: true` → modal aperta
3. Submit POST → server ri-verifica prima dell'INSERT
4. Race condition: `{ eligible: false }` → modal si chiude silenziosamente
5. Vittoria Master: bottone esplicito "🏆 Salva punteggio"

---

## Database Neon

- **Branch prod:** `main` | **Branch dev:** `dev`
- **Env var:** `POSTGRES_URL` in `.env.local` → deve puntare a `dev`
- **⚠️** Non lasciare `.env.development.local`

```sql
CREATE TABLE scores (
  id          SERIAL PRIMARY KEY,
  nickname    VARCHAR(12)  NOT NULL,
  score       INTEGER      NOT NULL,
  level       INTEGER      NOT NULL,
  level_name  VARCHAR(20)  NOT NULL,
  genre       VARCHAR(60)  NOT NULL,
  avg_time_ms INTEGER,
  created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_scores_score ON scores (score DESC);
```

---

## Security

| Punto | Protezione |
|-------|-----------|
| SQL injection | neon template literals = prepared statements |
| POST spam | Rate limit 5 req/min per IP (in-memory) |
| Score manipulation | Validazione server: score ≤ winScore×multiplier×2 |
| Top 50 bypass | Server ri-verifica eligibility prima dell'INSERT |
| Input overflow | artistName max 100 char, usedIds max 200 id |

---

## Jest

- `jest.config.js` usa `next/jest` wrapper
- `cacheDirectory: '<rootDir>/.jest-cache'`

---

## Cose da NON fare
- Non usare `@import` Google Fonts in `globals.css`
- Non tornare a Bebas Neue, Michroma, Oxanium per `--font-display` — scelto Syne
- Non mettere emoji nel navTitle di `game/page.tsx` — usa `GameNav` con `showDot`
- Non aprire il modal automaticamente su `isVictory=true`
- Non resettare `wonLevelRef` in `restartGame`
- Non usare classi BEM globali — CSS Modules
- Non usare `preset: 'ts-jest'` in jest.config.js
- Non aggiungere pattern SVG a GenreGrid — solo banda colorata
- Non usare `useMemo` per rilevare la lingua — causa hydration mismatch (usare `useState+useEffect`)
- Nomi livelli: Rookie / Arcade / Expert / Master
- Generi e livelli: non tradotti, rimangono in inglese
- Rate limit in-memory non condiviso tra istanze Vercel — limitazione nota