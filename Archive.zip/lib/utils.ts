/**
 * Utilità pure condivise tra i moduli.
 * Nessuna dipendenza da altri file del progetto.
 */

/** Fisher-Yates shuffle — non muta l'array originale */
export function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr]
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[copy[i], copy[j]] = [copy[j], copy[i]]
  }
  return copy
}
